<?php 

require "Connect.php";

$login = trim($_POST['login']);
$pass = trim($_POST['pass']);

$result1 = mysqli_query($con,"SELECT * FROM `Users` WHERE `login` = '$login'");
$user = mysqli_fetch_assoc($result1); // Конвертируем в массив

if(!empty($user)){
	echo "Авторизация прошла успешно !";
	exit();
}



if(count($user) == 0){
	echo "Такой пользователь не найден.";
	exit();
}
else if(count($user) == 1){
	echo "Логин или пароль введены неверно";
	exit();
}

setcookie('User', $user['name'], time() + 3600, "/");

header('Location: page.html');

?> 
