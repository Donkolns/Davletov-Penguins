<?php
$con = mysqli_connect('localhost','root', '', 'penguins_news');
?>