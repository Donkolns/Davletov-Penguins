<?php
// $userAvatar = $_FILES["userAvatar"];
// $userHeading = $_POST["userHeading"];
// $userText = $_POST["userText"];
// $rash = array('jpg', 'jpeg', 'png', 'svg');
// if (strlen($userHeading) <= "20") {
//     echo "Нормальная длина <br>";
// } else {
//     echo "Слишком много <br>";
// }

// if (empty($userHeading)) {
//     echo "Строка пустая <br>";
// } else {
//     echo "Строка заполненна <br>";
// }

// if (empty($userText)) {
//     echo "Строка пустая <br>";
// } else {
//     echo "Строка заполненна <br>";
// }

// if (in_array(explode('.', $userAvatar['name'])[1], $rash)) {
//     echo "Изображение!";
// } else {
//     echo "Ошибка!!!!!!!!!!!!!!!!!!!!!!!!!!!";
// }
 $inset = 
?>
