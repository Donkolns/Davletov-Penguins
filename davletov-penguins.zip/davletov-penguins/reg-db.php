<?php 
require "connect.php";

$login = trim($_POST['login']); // Удаляет все лишнее и записываем значение в переменную //$login
$name =trim($_POST['username']);
$pass = trim($_POST['pass']);

$result1 = mysqli_query($con,"SELECT * FROM `Users` WHERE `login` = '$login'");
$user1 = mysqli_fetch_assoc($result1); // Конвертируем в массив
if(!empty($user1)){
	echo "Данный логин уже используется!";
	exit();
}

 

if(mb_strlen($login) < 5 || mb_strlen($login) > 100){
	echo "Недопустимая длина логина";
	exit();
}
$res = "INSERT INTO `Users` (`login`, `username`, `pass`) VALUES ('$login', '$name','$pass')";
mysqli_query($con, $res);
