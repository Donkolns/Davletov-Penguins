<?php
include "../Connect.php";
include "../header.php";
$News = mysqli_fetch_all(mysqli_query($con, "SELECT news_id, title from News"));

$id_new = isset($_GET["new"]) ? $_GET["new"] : false;

if ($id_new) $new_info = mysqli_fetch_assoc(mysqli_query($con, "SELECT * from news where news_id =$id_new"));


?>

<div>
    <h1>Панель администратора</h1>
    <h2><?= $id_new ? "Редактирование новости" : "Создание новости" ?></h2>
    <ul>
        <?php foreach ($News as $new) {
            echo "<li><a href='?new=" . $new[0] . "'>" . $new[1] . "</a></li>";
        }
        ?>
    </ul>
    <a class="adding_a" href="index.php">
        <img src="../image/adding.png" alt="" height="60px" width="60px">
    </a>
    <a href="deleteNewValid.php" class="del-new">
        <img src="../image/free-icon-bin-484662.png" alt="" height="60px" width="60px">
    </a>
</div>


<?= $id_new ? "Редактирование новости №$id_new" : "Создание новости " ?>
<form action='<?= $id_new ? "update" : "create"; ?>NewValid.php' method="POST" enctype="multipart/form-data" id="form">
    <?php if ($id_new) {
        echo "<div class ='c_img'> <img src='../image/news/" . $new_info['image'] . "'></div>";
    }
    ?>

    <?= $id_new ? "<input type = 'hidden' name = 'id' value = '$id_new'>" : ""    ?>

    <label for="userAvatar"></label>
    <input name="userAvatar" type="file" id="userAvatar">

    <br>
    <label for="user"></label>
    <input name="userHeading" type="text" id="userHeading" placeholder="Введите Заголовок" value="<?= $id_new ? $new_info["title"] : ""; ?>">
    <br>
    <label for="userText"></label>
    <input name="userText" type="text" id="userText" placeholder="Введите текст" value="<?= $id_new ? $new_info["content"] : ""; ?>">
    <br>
    <label for="userSelect"></label>
    <select name="news" id="userSelect">
        <?php
        foreach ($categories as $category) {
            $id_cat = $category[0];
            $name = $category[1];
            $is_sel = ($id_cat == $new_info['category_id']) ? "selected" : '';
            echo "<option value = '$id_cat'" . ($id_cat ? $is_sel : '') . ">$name</option>";
        }
        ?>
    </select>
    <br>
    <input type="submit" value="Создать пост" id="userSubmit">
</form>
</body>

</html>